package com.homes.host;

public class HostDAO {

}
